#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_ARTISTAS 100
#define MAX_ALBUMS 10

typedef struct {
    char nome[100];
    char genero[50];
    char local[100];
    char albums[MAX_ALBUMS][100];
    int num_albums;
} Artista;

void carregarArtistas(FILE *arquivo, Artista artistas[], int *num_artistas) {
    char linha[1000];
    char nome[100], genero[50], local[100];
    char album[100];
    int num_albums = 0;

    while (fgets(linha, sizeof(linha), arquivo) != NULL) {
        if (strcmp(linha, "==========\n") == 0) {
            Artista novoArtista;
            strcpy(novoArtista.nome, nome);
            strcpy(novoArtista.genero, genero);
            strcpy(novoArtista.local, local);
            novoArtista.num_albums = num_albums;
            for (int i = 0; i < num_albums; i++) {
                strcpy(novoArtista.albums[i], album);
            }
            artistas[*num_artistas] = novoArtista;
            (*num_artistas)++;
            // Zerar variáveis temporárias
            strcpy(nome, "");
            strcpy(genero, "");
            strcpy(local, "");
            num_albums = 0;
        } else {
            if (strlen(nome) == 0) {
                strcpy(nome, linha);
            } else if (strlen(genero) == 0) {
                strcpy(genero, linha);
            } else if (strlen(local) == 0) {
                strcpy(local, linha);
            } else {
                strcpy(album, linha);
                num_albums++;
            }
        }
    }
}

void listarArtistas(Artista artistas[], int num_artistas) {
    printf("\nLista de Artistas:\n");
    for (int i = 0; i < num_artistas; i++) {
        printf("Nome: %s", artistas[i].nome);
        printf("Gênero: %s", artistas[i].genero);
        printf("Local: %s", artistas[i].local);
        printf("Álbuns:\n");
        for (int j = 0; j < artistas[i].num_albums; j++) {
            printf("  %s", artistas[i].albums[j]);
        }
        printf("==========\n");
    }
}

int main() {
    FILE *arquivo;
    arquivo = fopen("artistas.txt", "r");
    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo artistas.txt.\n");
        return 1;
    }

    Artista artistas[MAX_ARTISTAS];
    int num_artistas = 0;

    carregarArtistas(arquivo, artistas, &num_artistas);
    fclose(arquivo);

    int opcao;

    while (1) {
        printf("\nMenu:\n");
        printf("1. Listar artistas\n");
        printf("2. Sair\n");
        printf("Escolha uma opção: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1:
                listarArtistas(artistas, num_artistas);
                break;
            case 2:
                printf("Programa encerrado.\n");
                return 0;
            default:
                printf("Opção inválida. Tente novamente.\n");
        }
    }

    return 0;
}
