#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_ARTISTAS 100
#define MAX_ALBUMS 10

typedef struct {
    char nome[100];
    char genero[50];
    char local[100];
    char albums[MAX_ALBUMS][100];
    int num_albums;
} Artista;

void inserirArtista(Artista artistas[], int *num_artistas, Artista novoArtista) {
    if (*num_artistas < MAX_ARTISTAS) {
        int i = *num_artistas - 1;
        while (i >= 0 && strcmp(novoArtista.nome, artistas[i].nome) < 0) {
            artistas[i + 1] = artistas[i];
            i--;
        }
        artistas[i + 1] = novoArtista;
        (*num_artistas)++;
        printf("Artista inserido com sucesso!\n");
    } else {
        printf("Não é possível adicionar mais artistas. Limite atingido.\n");
    }
}

void removerArtista(Artista artistas[], int *num_artistas, char nome[]) {
    int i = 0;
    while (i < *num_artistas && strcmp(nome, artistas[i].nome) != 0) {
        i++;
    }
    if (i < *num_artistas) {
        for (int j = i; j < *num_artistas - 1; j++) {
            artistas[j] = artistas[j + 1];
        }
        (*num_artistas)--;
        printf("Artista removido com sucesso!\n");
    } else {
        printf("Artista não encontrado.\n");
    }
}

void editarArtista(Artista artistas[], int num_artistas, char nome[], Artista novoArtista) {
    int i = 0;
    while (i < num_artistas && strcmp(nome, artistas[i].nome) != 0) {
        i++;
    }
    if (i < num_artistas) {
        artistas[i] = novoArtista;
        printf("Artista editado com sucesso!\n");
    } else {
        printf("Artista não encontrado.\n");
    }
}

Artista *buscarArtistaBinario(Artista artistas[], int num_artistas, char nome[]) {
    int inicio = 0, fim = num_artistas - 1;
    while (inicio <= fim) {
        int meio = (inicio + fim) / 2;
        int comparacao = strcmp(nome, artistas[meio].nome);
        if (comparacao == 0) {
            return &artistas[meio];
        } else if (comparacao < 0) {
            fim = meio - 1;
        } else {
            inicio = meio + 1;
        }
    }
    return NULL;
}

void buscarAlbumSequencial(Artista artistas[], int num_artistas, char album[]) {
    int encontrado = 0;
    for (int i = 0; i < num_artistas; i++) {
        for (int j = 0; j < artistas[i].num_albums; j++) {
            if (strcmp(album, artistas[i].albums[j]) == 0) {
                printf("Artista: %s\n", artistas[i].nome);
                printf("Gênero: %s\n", artistas[i].genero);
                printf("Local: %s\n", artistas[i].local);
                printf("Álbum: %s\n", artistas[i].albums[j]);
                encontrado = 1;
            }
        }
    }
    if (!encontrado) {
        printf("Nenhum artista possui o álbum %s.\n", album);
    }
}

int main() {
    Artista *artistas = malloc(MAX_ARTISTAS * sizeof(Artista));
    int num_artistas = 0;

    FILE *arquivo;
    arquivo = fopen("artistas.txt", "r");
    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo artistas.txt.\n");
        return 1;
    }

    char linha[1000];
    char nome[100], genero[50], local[100];
    char album[100];
    int num_albums = 0;

    while (fgets(linha, sizeof(linha), arquivo) != NULL) {
        if (strcmp(linha, "==========\n") == 0) {
            Artista novoArtista;
            strcpy(novoArtista.nome, nome);
            strcpy(novoArtista.genero, genero);
            strcpy(novoArtista.local, local);
            novoArtista.num_albums = num_albums;
            for (int i = 0; i < num_albums; i++) {
                strcpy(novoArtista.albums[i], album);
            }
            inserirArtista(artistas, &num_artistas, novoArtista);

            // Zerar variáveis temporárias
            strcpy(nome, "");
            strcpy(genero, "");
            strcpy(local, "");
            num_albums = 0;
        } else {
            if (strlen(nome) == 0) {
                strcpy(nome, linha);
            } else if (strlen(genero) == 0) {
                strcpy(genero, linha);
            } else if (strlen(local) == 0) {
                strcpy(local, linha);
            } else {
                strcpy(album, linha);
                num_albums++;
            }
        }
    }

    fclose(arquivo);

    int opcao;

        while (1) {
        printf("\nMenu:\n");
        printf("1. Inserir novo artista\n");
        printf("2. Remover artista\n");
        printf("3. Editar artista\n");
        printf("4. Busca binária por um artista\n");
        printf("5. Busca sequencial por um álbum\n");
        printf("6. Sair\n");
        printf("Escolha uma opção: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1:
                if (num_artistas < MAX_ARTISTAS) {
                    Artista novoArtista;
                    printf("Nome do artista: ");
                    scanf(" %99[^\n]", novoArtista.nome);
                    printf("Gênero musical: ");
                    scanf(" %49[^\n]", novoArtista.genero);
                    printf("Local de criação/nascimento: ");
                    scanf(" %99[^\n]", novoArtista.local);
                    printf("Número de álbuns: ");
                    scanf("%d", &novoArtista.num_albums);
                    printf("Álbuns (separados por vírgula, até %d álbuns): ", MAX_ALBUMS);
                    for (int i = 0; i < novoArtista.num_albums; i++) {
                        scanf(" %99[^,]", novoArtista.albums[i]);
                    }
                    inserirArtista(artistas, &num_artistas, novoArtista);
                } else {
                    printf("Não é possível adicionar mais artistas. Limite atingido.\n");
                }
                break;
            case 2:
                if (num_artistas > 0) {
                    char nomeRemover[100];
                    printf("Nome do artista a ser removido: ");
                    scanf(" %99[^\n]", nomeRemover);
                    removerArtista(artistas, &num_artistas, nomeRemover);
                } else {
                    printf("Não há artistas para remover.\n");
                }
                break;
            case 3:
                if (num_artistas > 0) {
                    char nomeEditar[100];
                    printf("Nome do artista a ser editado: ");
                    scanf(" %99[^\n]", nomeEditar);
                    Artista *artistaEditar = buscarArtistaBinario(artistas, num_artistas, nomeEditar);
                    if (artistaEditar != NULL) {
                        printf("Nome do artista: ");
                        scanf(" %99[^\n]", artistaEditar->nome);
                        printf("Gênero musical: ");
                        scanf(" %49[^\n]", artistaEditar->genero);
                        printf("Local de criação/nascimento: ");
                        scanf(" %99[^\n]", artistaEditar->local);
                        printf("Número de álbuns: ");
                        scanf("%d", &artistaEditar->num_albums);
                        printf("Álbuns (separados por vírgula, até %d álbuns): ", MAX_ALBUMS);
                        for (int i = 0; i < artistaEditar->num_albums; i++) {
                            scanf(" %99[^,]", artistaEditar->albums[i]);
                        }
                        printf("Artista editado com sucesso!\n");
                    } else {
                        printf("Artista não encontrado.\n");
                    }
                } else {
                    printf("Não há artistas para editar.\n");
                }
                break;
            case 4:
                if (num_artistas > 0) {
                    char nomeBuscar[100];
                    printf("Nome do artista a ser buscado: ");
                    scanf(" %99[^\n]", nomeBuscar);
                    Artista *artistaEncontrado = buscarArtistaBinario(artistas, num_artistas, nomeBuscar);
                    if (artistaEncontrado != NULL) {
                        printf("Artista encontrado:\n");
                        printf("Nome: %s\n", artistaEncontrado->nome);
                        printf("Gênero musical: %s\n", artistaEncontrado->genero);
                        printf("Local de criação/nascimento: %s\n", artistaEncontrado->local);
                        printf("Álbuns:\n");
                        for (int i = 0; i < artistaEncontrado->num_albums; i++) {
                            printf("  %s\n", artistaEncontrado->albums[i]);
                        }
                    } else {
                        printf("Artista não encontrado.\n");
                    }
                } else {
                    printf("Não há artistas para buscar.\n");
                }
                break;
            case 5:
                if (num_artistas > 0) {
                    char albumBuscar[100];
                    printf("Nome do álbum a ser buscado: ");
                    scanf(" %99[^\n]", albumBuscar);
                    buscarAlbumSequencial(artistas, num_artistas, albumBuscar);
                } else {
                    printf("Não há artistas para buscar álbuns.\n");
                }
                break;
            case 6:
                printf("Programa encerrado.\n");
                free(artistas);
                return 0;
            default:
                printf("Opção inválida. Tente novamente.\n");
        }
    }

    return 0;
}

